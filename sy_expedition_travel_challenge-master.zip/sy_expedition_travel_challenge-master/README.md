# SY expedition travel challenge

An UI challenge where I picked [Anton Skvortsov](https://dribbble.com/AntonSKV)'s awesome [design](https://dribbble.com/shots/3787326-SY-Expedition-travel-animation?_=1561358158209#) and implemented it using Flutter.

Blog: https://fidev.io/sy-animation  
YouTube: [Part 1](https://www.youtube.com/watch?v=NmA5X4go3ns) and [Part 2](https://www.youtube.com/watch?v=Uvi4j2_d19k)  
Other challenges: https://fidev.io/design-challenges

## Design
![design](https://user-images.githubusercontent.com/16286046/64514994-09339100-d2ec-11e9-9fde-2b48aa5c222b.gif)
## Implementation
![implementation](https://user-images.githubusercontent.com/16286046/64514947-f91bb180-d2eb-11e9-9917-f152059b9557.gif)
