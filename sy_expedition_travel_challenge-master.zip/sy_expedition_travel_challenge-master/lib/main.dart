import 'package:flutter/material.dart';
import 'package:sy_expedition_travel_challenge/my_app.dart';

void main() => runApp(MyApp());
